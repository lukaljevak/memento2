package memgame.hemant.com.memorygame.utils;

/**
 * Created by Hemant on 10/6/15.
 */
public interface IAppConstants {

    public static final int ERROR_RESPONSE_DUPLICATE_ENTRY = 100;

}
