package memgame.hemant.com.memorygame.businesslayer;

/**
 * Notify object makes a generic result object.
 * 
 * Created by Hemant on 10/1/15.
 *
 */
public interface INotifyObject {

}
